<?php

namespace OpenAI\Testing\Responses\Fixtures\Threads;

final class ThreadDeleteResponseFixture
{
    public const ATTRIBUTES = [
        'id' => 'thread_agvtHUGezjTCt4SKgQg0NJ2Y',
        'object' => 'thread.deleted',
        'deleted' => true,
    ];
}
